//export const BACK_URL = 'http://localhost:3001';
export const BACK_URL = "https://backpf-production.up.railway.app";
export const FRONT_URL = "https://front-wheat-gamma.vercel.app";
// export const FRONT_URL = "http://localhost:3000";

