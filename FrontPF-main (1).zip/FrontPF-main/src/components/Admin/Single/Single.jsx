import React from "react";
/* import "../AdminHome/adminHome.scss"; */

export default function Single () {
    return(
        <div className="single">
            <h1 className="title">Single</h1>
        </div>
    )
};