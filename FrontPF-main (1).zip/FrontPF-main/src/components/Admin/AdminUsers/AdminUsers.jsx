import React from "react";
/* import "../AdminHome/adminHome.scss"; */

export default function AdminUsers () {
    return(
        <div className="homeUsers">
            <h1 className="title">AdminUsers</h1>
        </div>
    )
};