import React from "react";

const About = () => {
  return <div>Estas en / about</div>;
};

export default About;
