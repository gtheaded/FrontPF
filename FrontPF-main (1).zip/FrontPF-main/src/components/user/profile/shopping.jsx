import React from 'react';

const Shopping = () => {
    return ( 
        <div className='z-10 absolute bottom-0'><h1>Holaaaaaaaaaaaaaaaa</h1></div>
     );
}
 
export default Shopping;